<?php

use GeekBrains\Blog\Repositories\LikesRepository\LikesRepositoryInterface;
use GeekBrains\LevelTwo\Blog\Repositories\UsersRepository\UsersRepositoryInterface;
use GeekBrains\LevelTwo\Blog\Repositories\LikesRepository\LikesRepository;
use GeekBrains\Blog\Repositories\UserNotFoundException\UserNotFoundException;
use GeekBrains\LevelTwo\Blog\Repositories\LikesRepository\SqliteUsersRepository;
use GeekBrains\LevelTwo\Blog\Repositories\UsersRepository;

require __DIR__ . '/vendor/autoload.php';

$container = new DIContainer();

$container->bind(
   PDO::class,
   new PDO('sqlite:' . __DIR__ . '/blog.sqlite')
);

$container->bind (
   LikesRepositoryInterface::class,
   SqliteUsersRepository::class
);

$container->bind(
   PostsRepositoryInterface::class,
   SqlitePostsRepository::class
);

$container->bind(
  UsersRepositoryInterface::class,
  SqliteUsersRepository::class,
);