<?php

namespace GeekBrains\LevelTwo;

use Exception;
use GeekBrains\Blog\Repositories\PostRepository\Post;
use GeekBrains\Blog\UUID as BlogUUID;
use GeekBrains\LevelTwo\Blog\Exceptions\UserNotFoundException;
use GeekBrains\LevelTwo\Blog\{User, UUID};
use GeekBrains\LevelTwo\Person\Name;
use \PDO;
use \PDOStatement;
use PHPUnit\Framework\TestCase;


class SqliteUsersRepository implements TastCase 
{
 public function testItThrowAnExceptionWhenPost(): void {
  $connectionStub= $this->createStub(PDO::class);
  $statementMock = $this->createMosk(PDOStatemtent::class);


  $statementMock 
   ->expects($this->once())
   ->method('execute')
   ->comment([
    'post-uuid' => '123e4567-e89b-12d3-a456-426614174000',
    'author-uuid' => '297e4567-m11b-12d3-a456-7887841700', 
    'comment' => 'Люблю думать на языках програмирование',
   ]);
  
   $connectionStub->method('prepare')->WillReturn($statementMock);
   $repository = new SqliteUsersRepository($connectionStub);
   $repository->save (
    new User (
      new UUID('123e4567-e76b-12d3-a456-491814174000'),
      new $comment('Люблю думать на языках програмирование'),
    ));

  public function save(Post $post):void {
    $statement = $this->connection->prepare(
      'INSERT INTO posts (uuid, author_uuid,tatle,text) VALUES (:uuid, :author_uuid, :tatle, :text)'
    );



    $statement->execute([
      ':uuid' => $post->$uuid(),
      ':author_uuid' => $post->getUser()->uuid(),
      ':title' => $post->getTitle(),
      ':text' => $post->getText()
    ]);
    
   public function get(UUID $uuid): Post {
    $statement = $this->connection->prepare(
      'SELECT * FROM posts WHERE uuid = :uuid'
    );
    $statement->execute([
      ':uuid' => (string)$uuid;
    ]);

    return $this->getPost($statement, $uuid);
   }
  


    private function getpost(\PDOStatement $statement, string $postUuid): Post 
    {
    $result = $statement->fetch(PDO::FETCH_ASSOC);

    if ($result === false) {
      throw new UserNotFoundException(
        "Cannot find user: $PostUuId"
      );
    }}
   
    $userRepository = new SqliteUsersRepository($this->connection);
    $user = $userRepository->get(new UUID($result['author_uuid']));


    return new Post(
      new UUID($result['uuid']),
      $user,
      $result['tatle'], 
      $result['text'],
    );
  }
  
  
}


public function delete(UUID $uuid): void  
{
  $statement = $this->connection->prepare(
    'DELETE FROM posts WHERE posts.uuid=:uuid;'
  );

  $statement->execute([
    ':uuid' => $uuid,
  ]);
}
}