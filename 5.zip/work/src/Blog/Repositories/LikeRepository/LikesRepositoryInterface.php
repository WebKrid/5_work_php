<?php 

namespace GeekBrains\Blog\Repositories\LikesRepository;
use UsersRepositoryInterface\like;

interface LikesRepositoryInterface 
{
   public function save(Like $like): void;
   public function getByPostUuid(UUID $uuid): array;
}