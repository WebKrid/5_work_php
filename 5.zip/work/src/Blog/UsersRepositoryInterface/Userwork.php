<?php

use Userlike use GlobalUserlike;
use work\src\Http\Request;
use work\src\Http\Request;
use GeekBrains\LevelTwo\Blog\Posts\http.php;
use GeekBrains\LevelTwo\SqliteUsersRepository;

class Userlike {
   private int $article;
  private array $like;
   private  $user;
   public function__construct ($like, $article, $user) {
    private UserRepositoryInterace $save;
    $this->like = $like;
    $this->article = $article;
    $this->user = $user; 
   } )


public function $Save bind ( string $like, string $class)  {
        $this->like[$like] = $class;
      };
public function __construct (private array $get,private array $server,private int $this->$like;) {
  
}
public function method(): string {
  if (!array_key_exists('REQUEST_METHOD', $this->$Server )) {
    throw new HttpException('Cannot get method from the request');
  }
  return $this->server['REQUEST_METHOD'];
}
$save = new Request($_GET, $_SERVER);
$parameter = $save->query('some_parameter');
$header = $save->header('Some-Header');
$like = $save->query('Some-save');
$path = $save->path();