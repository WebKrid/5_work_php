<?php
namespace GeekBrains\LevelTwo\Blog;
namespace GeekBrains\Blog\Repositories\PostRepository;




class Post
{
    private int $id;
    private User $user;
    private string $title;
    private string $text;
    /**
     * Summary of __construct
     * @param int $id
     * @param User $user
     * @param string $title
     * @param string $text
     */
    public function __construct(int $id, User $user, string $title, string $text)
    {
        $this->id = $id;
        $this->user = $user;
        $this->title = $title;
        $this->text = $text;
    }

    public function __toString()
    {
        return $this->title . ' ' . $this->user . ' пишет: ' . $this->text . PHP_EOL;
    }

    public function getIdAuthor ()
    {
        
    }

    /**
     * Summary of getTitle
     * @return string
     */
    public function getTitle():string
    {
        return $this->title;
    }
    /**
     * Summary of setTitle
     * @param mixed $title
     * @return void
     */
    public function setTitle($title):void
    {
        $this->title = $title;

    }
}