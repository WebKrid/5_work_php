<?php
use GeekBrains\Blog\Exceptions\LikesRepository;
use GeekBrains\Blog\Exceptions\LikesRepositoryInterface;
use GeekBrains\LevelTwo\Blog\Like;
use GeekBrains\LevelTwo\Blog\UUID;
use GeekBrains\LevelTwo\Http\Actions\ActionInterface;
use GeekBrains\LevelTwo\Http\Actions\Posts\DeletePost;
use GeekBrains\LevelTwo\http\Request;
use GeekBrains\LevelTwo\Http\Response;

class CreatePostLike implements ActionInterface 
{
   public function __construct(
      private LikesRepositoryInterface $likesRepository,
   )
   {
   }
   public function  handle(Request $request): Response 
   {
   try {
      $postUuid = $request->JsonBodyFitld('post_uuid');
      $userUuid = $request->JsonBodyField('user_uuid');
   } catch (HttpException $e) {
      return new ErrorResponse($e->getMessage());
   }
   try {
      $this->likesRepository->checkUserLikePostEziest($postUuid, $userUuid);
   } catch (LikeAlreadyEziest $e) {
      return new ErrorResponse($e->getMessage());
   }

   $newLikeUuid = UUID::random();

   $like = new Like (
      uuid: $newLikeUuid,
      post_id: new UUID($postUuid),
      user_id: new UUID($userUuid);
   );

   $this->likesRepository->save($like);

   return new SuccessFulResponse(
      ['uuid' => (string)$newLikeUuid]
   );
   }
}