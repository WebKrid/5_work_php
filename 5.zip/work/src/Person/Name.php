<?php
namespace GeekBrains\LevelTwo\Person;
class Name
{
    private string $firstName;
    private string $lastName;
    /**
     * Summary of __construct
     * @param string $firstName
     * @param string $lastName
     */
    public function __construct(string $firstName, string $lastName)
    {
        $this->firstName = $firstName;
        $this->lastName = $lastName;
    }

    public function __toString():string
    {
        return $this->firstName . ' ' . $this->lastName;
    }

    /**
     * Summary of getFirstName
     * @return string
     */
    public function First():string
    {
        return $this->firstName;
    }
    /**
     * Summary of setFirstName
     * @param mixed $firstName
     * @return void
     */
    public function setFirstName($firstName):void
    {
        $this->firstName = $firstName;
    }
    /**
     * Summary of getLastName
     * @return string
     */
    public function Last():string
    {
        return $this->lastName;
    }
    /**
     * Summary of setLastName
     * @param mixed $lastName
     * @return void
     */
    public function setLastName($lastName):void
    {
        $this->lastName = $lastName;
    }
}