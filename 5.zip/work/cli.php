<?php

use GeekBrains\LevelTwo\Blog\{User, Post};
use GeekBrains\LevelTwo\Blog\Comment;
use GeekBrains\LevelTwo\Person\{Name, Person};
use GeekBrains\LevelTwo\Blog\Repositories\InMemoryUsersRepository;
use \GeekBrains\LevelTwo\Blog\Exceptions\UserNotFoundException;
$container = require __DIR__ . '/Conteiner.php';
$command = $container->get(CreateUserCommand::class);


include __DIR__ . '/vendor/autoload.php';
function load($className)
{
    $file = $className . '.php';
    $file = str_replace("GeekBrains\LevelTwo", "src", $file);
    $file = str_replace("\\", "/", $file);
    $file = str_replace("_", "/", $file);
    if(file_exists($file)) {
        include $file;
    }
}
$faker = Faker\Factory::create('ru_RU');

$name = new Name(
    $faker->firstName('female'),
    $faker->lastName('female')
);
$user = new User(
    $faker->randomDigitNotNull(),
    $name,
    $faker->sentence(1)
);




$userRepository = new InMemoryUsersRepository();




switch ($argv[1] ?? null) {
    case 'user':
        echo $user;
        break;
    case 'post':
        $post = new Post(
            $faker->randomDigitNotNull(),
            $user,
            "Начало",
            $faker->realText(rand(100, 150))
        );
        echo $post;
        break;
    case 'comment':
        $post = new Post(
            $faker->randomDigitNotNull(),
            $user,
            "Начало",
            $faker->realText(rand(100, 150))
        );
        $comment = new Comment(
            $faker->randomDigitNotNull(),
            $user,
            $post,
            $faker->realText(rand(50, 100))
        );
        echo $comment;
        break;
    default:
        echo 'Ошибка';
}
